import { Component, OnInit } from '@angular/core';
import { Product } from './products';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  listData = [];
  constructor(private dataService: DataService) {
  }
  ngOnInit(): void {
    this.getData();
  }
  getData(): void {
    this.dataService.getAll().subscribe((data:Product[]) => {
      this.listData = data;
      console.log(data["decor"])
    })
  }
  ds(e) {
        var parent = (<HTMLElement>e.target).parentElement;
        // console.log(parent)
        var classList = parent.classList;
        if (classList.contains("open")) {
          classList.remove('open');
          var opensubs = parent.querySelectorAll(':scope .open');
          for (var i = 0; i < opensubs.length; i++) {
            opensubs[i].classList.remove('open');
          }
        } else {
          classList.add('open');
        }
  }

}
