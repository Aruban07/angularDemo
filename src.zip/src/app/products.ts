export interface Product {
    "furniture":[
        {
            name:string,
            color:string,
            rate:number,
            sales:string
        }
    ]
    "decor":[
        {
            name:string,
            color:string,
            rate:number,
            sales:string
        }
    ],
    
}